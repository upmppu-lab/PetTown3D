using System;
using System.Collections.Generic;
using UnityEngine;

// Pet Town 3D - standalone prototype. Every visual is a replaceable GameObject.
// No third-party assets or packages are required.
public class PetTownGame : MonoBehaviour
{
    enum Mode { Start, Play, Build, Furniture, Customize }
    Mode mode = Mode.Start;
    readonly List<GameObject> buildings = new List<GameObject>();
    readonly List<GameObject> props = new List<GameObject>();
    readonly List<GameObject> fog = new List<GameObject>();
    readonly List<GameObject> villagers = new List<GameObject>();
    GameObject hero, cameraPivot, shop, roof, ghost;
    Transform heroLeftArm, heroRightArm, heroLeftLeg, heroRightLeg;
    float walkPhase;
    Animator meshyAnimator;
    bool usingMeshyPlayer;
    bool meshyWasMoving;
    Animation[] meshyLegacyAnimations;
    bool meshyLegacyPresent;
    Camera cam;
    Material grass, road, water, dark, wood, wall, roofMat, skin, shirt, hairMat;
    Material foliageLight, foliageDark, trim, windowMat, gold, blush;
    int money = 2500, population = 0, sold = 0, inventory = 4;
    int reputation=0, shopLevel=1, day=1, completedOrders=0, missedOrders=0;
    int dogStock=2, catStock=2, rabbitStock=0;
    float dayTimer=0f, orderTimer=0f, orderDeadline=0f;
    int orderPet=-1;
    GameObject waitingCustomer;
    readonly string[] petNames={"Puppy", "Kitten", "Bunny"};
    int selected = 0, hairStyle = 0, faceStyle = 0, bodyStyle = 0, legStyle = 0, accessory = 0;
    int furnitureChoice = 0;
    float worldClock, customerClock, noticeTime, zoom = 39f;
    float cameraYaw = 42f, cameraPitch = 48f;
    Vector3 cameraFocus = Vector3.zero;
    string notice = "Choose a location for your first Pet Shop";
    bool showRoofs = false;
    Vector3 shopPosition;
    const int WorldSize = 220;
    readonly string[] types = { "Pet Shop", "Home", "Resident House", "Pet Cafe", "Pet Hospital", "Park", "Lake", "Zoo", "Road" };
    readonly int[] costs = { 0, 600, 250, 1500, 1800, 450, 700, 2400, 20 };
    readonly string[] furniture = { "Counter", "Pet Bed", "Display", "Chair", "Table", "Plant" };
    GUIStyle titleStyle, textStyle, buttonStyle;

    void Start()
    {
        Application.targetFrameRate = 60;
        grass = Mat(new Color(.39f,.67f,.37f)); road=Mat(new Color(.55f,.52f,.48f));
        water=Mat(new Color(.18f,.58f,.78f)); dark=Mat(new Color(.22f,.19f,.29f));
        wood=Mat(new Color(.68f,.44f,.26f)); wall=Mat(new Color(.97f,.87f,.73f));
        roofMat=Mat(new Color(.82f,.35f,.39f)); skin=Mat(new Color(1f,.79f,.65f));
        shirt=Mat(new Color(.42f,.66f,.92f)); hairMat=Mat(new Color(.35f,.23f,.16f));
        foliageLight=Mat(new Color(.60f,.79f,.42f));foliageDark=Mat(new Color(.24f,.50f,.33f));
        trim=Mat(new Color(.98f,.94f,.82f));windowMat=Mat(new Color(.45f,.76f,.87f));
        gold=Mat(new Color(.97f,.76f,.34f));blush=Mat(new Color(.97f,.55f,.54f));
        BuildWorld();
        SetupCamera();
        LoadGame();
        if (shop == null) { mode=Mode.Start; Message("Choose a flat area and click to place your Pet Shop"); }
        else mode=Mode.Play;
    }

    Material Mat(Color c) { var m = new Material(Shader.Find("Standard")); m.color=c; return m; }
    GameObject Part(PrimitiveType primitive, string name, Vector3 p, Vector3 scale, Material m, Transform parent=null)
    {
        GameObject o=GameObject.CreatePrimitive(primitive); o.name=name; o.transform.position=p;
        o.transform.localScale=scale; if(parent!=null) o.transform.SetParent(parent,true);
        o.GetComponent<Renderer>().sharedMaterial=m; return o;
    }
    float Height(float x,float z)
    {
        float h = Mathf.PerlinNoise(x*.018f+4,z*.018f+7)*7.5f-3.0f;
        h += Mathf.PerlinNoise(x*.052f+2,z*.052f+6)*1.1f;
        return h;
    }
    bool IsWater(float x,float z)
    {
        float river = Mathf.Sin(z*.031f)*12f+Mathf.Sin(z*.09f)*3f;
        return Mathf.Abs(x-river)<3.5f || (x>52 && x<72 && z>35 && z<66);
    }
    float Ground(float x,float z) { return IsWater(x,z) ? -.5f : Height(x,z); }
    void BuildWorld()
    {
        int n=110; float step=2f;
        Vector3[] vertices=new Vector3[(n+1)*(n+1)]; Vector2[] uv=new Vector2[vertices.Length];
        int[] triangles=new int[n*n*6];
        for(int z=0;z<=n;z++) for(int x=0;x<=n;x++)
        {
            int i=z*(n+1)+x; float px=x*step-110,pz=z*step-110;
            vertices[i]=new Vector3(px,Ground(px,pz),pz); uv[i]=new Vector2(x*.15f,z*.15f);
        }
        int t=0; for(int z=0;z<n;z++) for(int x=0;x<n;x++)
        {
            int i=z*(n+1)+x;
            triangles[t++]=i;triangles[t++]=i+n+1;triangles[t++]=i+1;
            triangles[t++]=i+1;triangles[t++]=i+n+1;triangles[t++]=i+n+2;
        }
        Mesh mesh=new Mesh(); mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.vertices=vertices;mesh.uv=uv;mesh.triangles=triangles;mesh.RecalculateNormals();
        GameObject terrain=new GameObject("EDITABLE_Terrain_Mesh");
        terrain.AddComponent<MeshFilter>().sharedMesh=mesh;
        terrain.AddComponent<MeshRenderer>().sharedMaterial=grass;
        terrain.AddComponent<MeshCollider>().sharedMesh=mesh;
        // Water overlay; river is visible as a continuous ribbon following its winding path.
        var riverParent=new GameObject("River_And_Streams");
        for(int z=-106;z<106;z+=3)
        {
            float x=Mathf.Sin(z*.031f)*12f+Mathf.Sin(z*.09f)*3f;
            Part(PrimitiveType.Cube,"River",new Vector3(x,-.24f,z),new Vector3(7.2f,.18f,3.5f),water,riverParent.transform);
        }
        Part(PrimitiveType.Cylinder,"Lake_Water",new Vector3(62,-.3f,50),new Vector3(21,.12f,24),water);
        // Sparse trees and low grass clusters.
        var random=new System.Random(41);
        for(int i=0;i<125;i++)
        {
            float x=(float)random.NextDouble()*204-102,z=(float)random.NextDouble()*204-102;
            if(IsWater(x,z) || (x>58 && z>55) || Mathf.Abs(x)<15 && Mathf.Abs(z)<15) continue;
            if(i%3==0) MakeTree(new Vector3(x,Ground(x,z),z));
            else Part(PrimitiveType.Capsule,"Grass_Clump",new Vector3(x,Ground(x,z)+.2f,z),new Vector3(.22f,.4f,.22f),grass);
        }
        // The far-side rival village is present from the beginning.
        CreateBuilding(2,new Vector3(76,Ground(76,-76),-76),true);
        CreateBuilding(2,new Vector3(88,Ground(88,-70),-70),true);
        CreateBuilding(0,new Vector3(80,Ground(80,-84),-84),true);
        for(int i=0;i<6;i++) Part(PrimitiveType.Cube,"Dark_Fog",new Vector3(75+i*5,8,-74),new Vector3(6,15,55),Mat(new Color(.31f,.29f,.4f,.20f)));
        var sun=new GameObject("Sun"); var light=sun.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.2f;
        sun.transform.rotation=Quaternion.Euler(45,-35,0);
        RenderSettings.ambientLight=new Color(.72f,.75f,.79f);
    }
    void MakeTree(Vector3 p)
    {
        var root=new GameObject("Replaceable_Tree");root.transform.position=p;
        Part(PrimitiveType.Cylinder,"Trunk",p+Vector3.up*1.15f,new Vector3(.5f,1.15f,.5f),wood,root.transform);
        Part(PrimitiveType.Sphere,"Crown_Lower",p+Vector3.up*2.45f,new Vector3(2.65f,2.1f,2.6f),foliageDark,root.transform);
        Part(PrimitiveType.Sphere,"Crown_Top",p+Vector3.up*3.2f,new Vector3(2.05f,2.0f,2.05f),foliageLight,root.transform);
    }
    void SetupCamera()
    {
        var c=new GameObject("PetTown_Camera"); cam=c.AddComponent<Camera>();cam.orthographic=true;cam.orthographicSize=zoom;
        cam.transform.rotation=Quaternion.Euler(cameraPitch,cameraYaw,0);
        cam.transform.position=cameraFocus-cam.transform.forward*75f;
        cam.backgroundColor=new Color(.66f,.83f,.94f);
    }
    void Update()
    {
        if(cam==null)return;
        float dt=Time.deltaTime; worldClock+=dt;
        if(Input.GetKeyDown(KeyCode.Escape)) { mode=Mode.Play; ClearGhost(); }
        float h=Input.GetAxisRaw("Horizontal"),v=Input.GetAxisRaw("Vertical");
        Vector3 forward=Vector3.ProjectOnPlane(cam.transform.forward,Vector3.up).normalized;
        Vector3 right=Vector3.ProjectOnPlane(cam.transform.right,Vector3.up).normalized;
        if(hero!=null && mode==Mode.Play && (Mathf.Abs(h)+Mathf.Abs(v)>.1f))
        {
            Vector3 move=(forward*v+right*h).normalized*dt*8;
            Vector3 next=hero.transform.position+move;
            if(!IsWater(next.x,next.z))
            {
                next.y=Ground(next.x,next.z);hero.transform.position=next;
                // The placeholder face and shoes are authored toward local -Z, not +Z.
                hero.transform.rotation=Quaternion.Slerp(hero.transform.rotation,Quaternion.LookRotation(usingMeshyPlayer ? move : -move),dt*10);
            }
        }
        // glTFast GLB imports may use Unity Legacy Animation, not Animator.
        // Control BOTH systems so an imported autoplay Running clip cannot keep playing.
        bool shouldRun = mode==Mode.Play && (Mathf.Abs(h)+Mathf.Abs(v)>.1f);
        if (meshyLegacyAnimations != null && meshyLegacyAnimations.Length>0)
        {
            foreach (var legacy in meshyLegacyAnimations)
            {
                if (legacy==null) continue;
                if (shouldRun)
                {
                    if (!legacy.isPlaying)
                    {
                        string clipName = null;
                        foreach (AnimationState state in legacy)
                        {
                            if (state.name.ToLowerInvariant().Contains("running")) { clipName=state.name; break; }
                            if (clipName==null && state.name.ToLowerInvariant().Contains("walking")) clipName=state.name;
                            if (clipName==null) clipName=state.name;
                        }
                        if (!string.IsNullOrEmpty(clipName))
                        {
                            legacy.wrapMode=WrapMode.Loop;
                            legacy.Play(clipName);
                        }
                    }
                }
                else if (legacy.isPlaying) legacy.Stop();
            }
        }
        if (meshyAnimator!=null)
        {
            // The Legacy Animation component owns imported GLB clips when present.
            // Disable Animator in that case to prevent competing bone transforms.
            if (meshyLegacyPresent)
            {
                if (meshyAnimator.enabled) meshyAnimator.enabled=false;
            }
            else
            {
                meshyAnimator.enabled=true;
                if (meshyAnimator.runtimeAnimatorController!=null)
                {
                    if (shouldRun && !meshyWasMoving)
                    {
                        meshyAnimator.speed=1f;
                        meshyAnimator.Play("Running",0,0f);
                    }
                    else if (!shouldRun && meshyWasMoving)
                    {
                        meshyAnimator.speed=0f;
                    }
                }
                else meshyAnimator.speed=0f;
            }
        }
        meshyWasMoving=shouldRun;
        if(heroLeftArm!=null && !usingMeshyPlayer)
        {
            bool walking=hero!=null && mode==Mode.Play && (Mathf.Abs(h)+Mathf.Abs(v)>.1f);
            walkPhase+=dt*(walking?11f:3f);
            float swing=walking?Mathf.Sin(walkPhase)*32f:Mathf.Sin(walkPhase)*3f;
            heroLeftArm.localRotation=Quaternion.Euler(swing,0,0);
            heroRightArm.localRotation=Quaternion.Euler(-swing,0,0);
            heroLeftLeg.localRotation=Quaternion.Euler(-swing*.65f,0,0);
            heroRightLeg.localRotation=Quaternion.Euler(swing*.65f,0,0);
        }
        // Right mouse drag rotates the quarter-view camera around its focus.
        // Q/E rotate in 45-degree increments; R restores the original quarter view.
        if(Input.GetMouseButton(1))
        {
            cameraYaw += Input.GetAxis("Mouse X")*3f;
            cameraPitch = Mathf.Clamp(cameraPitch-Input.GetAxis("Mouse Y")*2f,25f,75f);
        }
        if(Input.GetKeyDown(KeyCode.Q))cameraYaw-=45f;
        if(Input.GetKeyDown(KeyCode.E))cameraYaw+=45f;
        if(Input.GetKeyDown(KeyCode.R)){cameraYaw=42f;cameraPitch=48f;}
        if(Input.GetMouseButton(2))cameraFocus+=(-right*Input.GetAxis("Mouse X")-forward*Input.GetAxis("Mouse Y"))*.7f;
        zoom=Mathf.Clamp(zoom-Input.mouseScrollDelta.y*2,10,75);cam.orthographicSize=zoom;
        if(hero!=null && mode==Mode.Play && !Input.GetMouseButton(2))
            cameraFocus=Vector3.Lerp(cameraFocus,hero.transform.position+Vector3.up*1.5f,dt*2f);
        cam.transform.rotation=Quaternion.Euler(cameraPitch,cameraYaw,0);
        cam.transform.position=cameraFocus-cam.transform.forward*75f;
        if((mode==Mode.Start||mode==Mode.Build||mode==Mode.Furniture) && !IsPointerOverUI())
        {
            Vector3 p; if(MouseGround(out p))
            {
                if(ghost!=null) ghost.transform.position=new Vector3(p.x,Ground(p.x,p.z),p.z);
                if(Input.GetMouseButtonDown(0)) Place(p);
            }
        }
        if(shop!=null)
        {
            dayTimer+=dt;
            if(dayTimer>120f) {dayTimer=0;day++;money-=Mathf.Min(80,30+population*2);Message("New day! Shop maintenance paid.");SaveGame();}
            orderTimer+=dt;
            if(orderPet<0 && orderTimer>8f) StartOrder();
            if(orderPet>=0 && Time.time>orderDeadline) FailOrder();
            customerClock+=dt;
            // Customers must be served manually. Automatic income is disabled.
            foreach(var person in villagers) if(person!=null)
            {
                Vector3 toward=shopPosition-person.transform.position; toward.y=0;
                if(toward.magnitude>4f) person.transform.position+=toward.normalized*dt*1.3f;
            }
        }
        if(Input.GetKeyDown(KeyCode.F5)) SaveGame();
        if(Input.GetKeyDown(KeyCode.E) && orderPet>=0) ServeOrder();
    }
    bool IsPointerOverUI() { return Input.mousePosition.y>Screen.height-110 || Input.mousePosition.x<270; }
    bool MouseGround(out Vector3 p)
    {
        Ray ray=cam.ScreenPointToRay(Input.mousePosition); RaycastHit hit;
        if(Physics.Raycast(ray,out hit,500f))
        {
            p=hit.point; return true;
        }
        Plane plane=new Plane(Vector3.up,Vector3.zero);float distance;
        if(plane.Raycast(ray,out distance)) { p=ray.GetPoint(distance);return true; }
        p=Vector3.zero;return false;
    }
    void Place(Vector3 p)
    {
        p=new Vector3(Mathf.Round(p.x/2)*2,Ground(p.x,p.z),Mathf.Round(p.z/2)*2);
        if(IsWater(p.x,p.z)) {Message("Cannot build in water");return;}
        if(mode==Mode.Start)
        {
            shop=CreateBuilding(0,p,false);shopPosition=p;CreateHero(p+new Vector3(8,0,8));
            dogStock=2;catStock=2;rabbitStock=0;inventory=4;CreatePetDisplays();
            mode=Mode.Play;Message("Pet Shop opened! Build a town and sell pets.");SaveGame();return;
        }
        if(mode==Mode.Furniture)
        {
            if(shop==null || Vector3.Distance(p,shopPosition)>12){Message("Furniture must be placed inside the Pet Shop");return;}
            if(money<50){Message("Not enough coins");return;}
            money-=50;CreateFurniture(furnitureChoice,p);reputation++;SaveGame();return;
        }
        if(mode==Mode.Build)
        {
            if(money<costs[selected]) {Message("Not enough coins");return;}
            money-=costs[selected];
            CreateBuilding(selected,p,false);
            if(selected==2)population+=2;
            if(selected==5)reputation+=2;
            if(selected==3||selected==4)reputation+=5;
            Message(types[selected]+" built");SaveGame();
        }
    }
    GameObject CreateBuilding(int kind,Vector3 p,bool rival)
    {
        var root=new GameObject((rival?"Dark_":"")+types[kind].Replace(" ","_")+"_REPLACEABLE");
        root.transform.position=p;
        Material m=rival?dark:wall;
        if(kind==8)
        {
            Part(PrimitiveType.Cube,"Road_Tile",p+Vector3.up*.06f,new Vector3(5,.12f,5),road,root.transform);
        }
        else if(kind==5||kind==6||kind==7)
        {
            Part(PrimitiveType.Cube,"Open_Ground",p+Vector3.up*.12f,new Vector3(kind==7?22:15,.25f,kind==7?22:15),kind==6?water:grass,root.transform);
            if(kind==5) for(int i=0;i<4;i++) MakeTree(p+new Vector3(i*3-4,0,5));
            if(kind==7) for(int i=0;i<4;i++) Part(PrimitiveType.Cube,"Zoo_Enclosure",p+new Vector3(i*4-6,.4f,0),new Vector3(3,.8f,4),wood,root.transform);
        }
        else
        {
            bool open=kind==0||kind==1||kind==3||kind==4;
            float w=kind==0?15:kind==2?7:11, d=kind==0?13:kind==2?7:10;
            Part(PrimitiveType.Cube,"Editable_Floor",p+Vector3.up*.2f,new Vector3(w,.4f,d),wood,root.transform);
            Part(PrimitiveType.Cube,"Back_Wall",p+new Vector3(0,2.5f,d/2),new Vector3(w,5,.35f),m,root.transform);
            Part(PrimitiveType.Cube,"Back_Trim",p+new Vector3(0,4.85f,d/2-.23f),new Vector3(w,.28f,.15f),trim,root.transform);
            for(int i=-1;i<=1;i++)
            {
                Part(PrimitiveType.Cube,"Window_Glass",p+new Vector3(i*w*.27f,2.95f,d/2-.28f),new Vector3(1.25f,1.55f,.09f),windowMat,root.transform);
                Part(PrimitiveType.Cube,"Window_Sill",p+new Vector3(i*w*.27f,2.13f,d/2-.37f),new Vector3(1.55f,.17f,.22f),trim,root.transform);
            }
            Part(PrimitiveType.Cube,"Left_Wall",p+new Vector3(-w/2,2.5f,0),new Vector3(.35f,5,d),m,root.transform);
            if(!open)
            {
                Part(PrimitiveType.Cube,"Right_Wall",p+new Vector3(w/2,2.5f,0),new Vector3(.35f,5,d),m,root.transform);
                Part(PrimitiveType.Cube,"Front_Wall",p+new Vector3(0,2.5f,-d/2),new Vector3(w,5,.35f),m,root.transform);
            }
            Part(PrimitiveType.Cube,"Foundation_Trim",p+new Vector3(0,.39f,0),new Vector3(w+.35f,.13f,d+.35f),trim,root.transform);
            var top=Part(PrimitiveType.Cube,"Toggle_Roof",p+new Vector3(0,5.4f,0),new Vector3(w+1,.65f,d+1),rival?dark:roofMat,root.transform);
            top.SetActive(!open||showRoofs);
            if(kind==0&&!rival)
            {
                shop=root;shopPosition=p;
                CreateFurniture(0,p+new Vector3(0,0,-2));
                CreateFurniture(1,p+new Vector3(-4,0,2));
                CreateFurniture(2,p+new Vector3(4,0,2));
            }
            if(kind==1&&!rival) CreateFurniture(4,p+new Vector3(0,0,0));
        }
        if(!rival)buildings.Add(root);
        return root;
    }
    void CreateFurniture(int type,Vector3 p)
    {
        var root=new GameObject("Furniture_"+furniture[type]+"_REPLACEABLE");root.transform.position=p;
        var m=type==5?grass:type==1?roofMat:wood;
        Part(PrimitiveType.Cube,"Body",p+Vector3.up*.65f,new Vector3(type==0?3:1.6f,1.2f,1.4f),m,root.transform);
        if(type==5) Part(PrimitiveType.Sphere,"Leaves",p+Vector3.up*1.7f,new Vector3(1.5f,1.4f,1.5f),grass,root.transform);
        props.Add(root);
    }
    void CreateHero(Vector3 p)
    {
        hero=new GameObject("PLAYER_Customizable_3D");hero.transform.position=new Vector3(p.x,Ground(p.x,p.z),p.z);
        RebuildHero();
    }
    // All body components are child objects and can be replaced with Meshy meshes later.
    Transform Joint(string name,Vector3 local,Transform parent)
    {
        var joint=new GameObject(name).transform;
        joint.SetParent(parent,false);joint.localPosition=local;
        return joint;
    }
    GameObject LocalPart(PrimitiveType type,string name,Transform parent,Vector3 pos,Vector3 size,Material material)
    {
        GameObject item=Part(type,name,parent.position, size,material,parent);
        item.transform.localPosition=pos;item.transform.localRotation=Quaternion.identity;
        Collider col=item.GetComponent<Collider>();if(col!=null)Destroy(col);
        return item;
    }
    void BuildPerson(Transform root,bool player,int variant)
    {
        Material outfit=player?shirt:Mat(Color.HSVToRGB((variant*.17f+.1f)%1f,.43f,.85f));
        var torso=LocalPart(PrimitiveType.Capsule,"BODY_REPLACEABLE",root,new Vector3(0,1.53f,0),new Vector3(.92f,1.04f,.68f),outfit);
        torso.transform.localScale*=1f+(player?bodyStyle*.08f:0);
        LocalPart(PrimitiveType.Sphere,"NECK",root,new Vector3(0,2.10f,0),new Vector3(.29f,.29f,.27f),skin);
        LocalPart(PrimitiveType.Sphere,"FACE_REPLACEABLE",root,new Vector3(0,2.68f,0),new Vector3(1.23f,1.16f,1.09f),skin);
        LocalPart(PrimitiveType.Sphere,"HAIR_REPLACEABLE",root,new Vector3(0,3.12f,.04f),new Vector3(1.27f,.48f+(player?hairStyle*.1f:0),1.12f),player?hairMat:dark);
        LocalPart(PrimitiveType.Sphere,"Hair_Fringe",root,new Vector3(0,2.95f,-.48f),new Vector3(1.03f,.24f,.28f),player?hairMat:dark);
        for(int sign=-1;sign<=1;sign+=2)
        {
            LocalPart(PrimitiveType.Sphere,"Eye",root,new Vector3(sign*.245f,2.69f,-.514f),new Vector3(.145f,.19f,.10f),dark);
            LocalPart(PrimitiveType.Sphere,"Eye_Shine",root,new Vector3(sign*.27f,2.76f,-.59f),new Vector3(.05f,.06f,.03f),trim);
            LocalPart(PrimitiveType.Sphere,"Cheek",root,new Vector3(sign*.44f,2.49f,-.43f),new Vector3(.19f,.09f,.04f),blush);
        }
        LocalPart(PrimitiveType.Sphere,"Nose",root,new Vector3(0,2.52f,-.552f),new Vector3(.095f,.075f,.055f),gold);
        Transform leftArm=Joint("LEFT_ARM_PIVOT",new Vector3(-.57f,1.98f,0),root);
        Transform rightArm=Joint("RIGHT_ARM_PIVOT",new Vector3(.57f,1.98f,0),root);
        LocalPart(PrimitiveType.Capsule,"LEFT_ARM_REPLACEABLE",leftArm,new Vector3(-.13f,-.46f,0),new Vector3(.33f,.61f,.36f),outfit);
        LocalPart(PrimitiveType.Capsule,"RIGHT_ARM_REPLACEABLE",rightArm,new Vector3(.13f,-.46f,0),new Vector3(.33f,.61f,.36f),outfit);
        LocalPart(PrimitiveType.Sphere,"Left_Hand",leftArm,new Vector3(-.15f,-.91f,0),new Vector3(.32f,.30f,.31f),skin);
        LocalPart(PrimitiveType.Sphere,"Right_Hand",rightArm,new Vector3(.15f,-.91f,0),new Vector3(.32f,.30f,.31f),skin);
        Transform leftLeg=Joint("LEFT_LEG_PIVOT",new Vector3(-.25f,1.06f,0),root);
        Transform rightLeg=Joint("RIGHT_LEG_PIVOT",new Vector3(.25f,1.06f,0),root);
        float legExtra=player?legStyle*.055f:0;
        LocalPart(PrimitiveType.Capsule,"LEFT_LEG_REPLACEABLE",leftLeg,new Vector3(0,-.39f,0),new Vector3(.38f,.55f+legExtra,.4f),dark);
        LocalPart(PrimitiveType.Capsule,"RIGHT_LEG_REPLACEABLE",rightLeg,new Vector3(0,-.39f,0),new Vector3(.38f,.55f+legExtra,.4f),dark);
        LocalPart(PrimitiveType.Sphere,"Left_Shoe",leftLeg,new Vector3(0,-.79f,-.15f),new Vector3(.46f,.24f,.65f),wood);
        LocalPart(PrimitiveType.Sphere,"Right_Shoe",rightLeg,new Vector3(0,-.79f,-.15f),new Vector3(.46f,.24f,.65f),wood);
        if(player)
        {
            heroLeftArm=leftArm;heroRightArm=rightArm;heroLeftLeg=leftLeg;heroRightLeg=rightLeg;
            if(accessory>0)
            {
                LocalPart(PrimitiveType.Cylinder,"ACCESSORY_REPLACEABLE",root,new Vector3(0,3.42f,0),new Vector3(1.4f,.12f,1.35f),roofMat);
                LocalPart(PrimitiveType.Cylinder,"Hat_Top",root,new Vector3(0,3.62f,.13f),new Vector3(1f,.23f,1f),roofMat);
            }
        }
    }
    void RebuildHero()
    {
        if(hero==null)return;
        for(int i=hero.transform.childCount-1;i>=0;i--) Destroy(hero.transform.GetChild(i).gameObject);
        heroLeftArm=heroRightArm=heroLeftLeg=heroRightLeg=null;
        meshyAnimator=null;
        meshyWasMoving=false;
        meshyLegacyAnimations=null;
        meshyLegacyPresent=false;
        usingMeshyPlayer=false;
        GameObject model=Resources.Load<GameObject>("MeshyPlayer");
        if(model!=null)
        {
            GameObject instance=Instantiate(model,hero.transform);
            instance.name="MESHY_CHARACTER_REPLACEABLE";
            instance.transform.localPosition=Vector3.zero;
            instance.transform.localRotation=Quaternion.identity;
            // Normalize the imported FBX height and place its feet on the ground.
            var renderers=instance.GetComponentsInChildren<Renderer>();
            if(renderers.Length>0)
            {
                Bounds bounds=renderers[0].bounds;
                for(int i=1;i<renderers.Length;i++)bounds.Encapsulate(renderers[i].bounds);
                float scale=Mathf.Clamp(3.3f/Mathf.Max(.001f,bounds.size.y), .01f, 100f);
                instance.transform.localScale=Vector3.one*scale;
                // Bounds must be recalculated after scaling.
                renderers=instance.GetComponentsInChildren<Renderer>();
                bounds=renderers[0].bounds;
                for(int i=1;i<renderers.Length;i++)bounds.Encapsulate(renderers[i].bounds);
                instance.transform.position+=Vector3.up*(hero.transform.position.y-bounds.min.y);
            }
            foreach(var c in instance.GetComponentsInChildren<Collider>())Destroy(c);
            meshyAnimator=instance.GetComponentInChildren<Animator>(true);
            if(meshyAnimator==null)meshyAnimator=instance.AddComponent<Animator>();
            RuntimeAnimatorController controller=Resources.Load<RuntimeAnimatorController>("MeshyRun");
            if(controller!=null)meshyAnimator.runtimeAnimatorController=controller;
            meshyAnimator.applyRootMotion=false;
            meshyLegacyAnimations=instance.GetComponentsInChildren<Animation>(true);
            meshyLegacyPresent=false;
            foreach(var legacy in meshyLegacyAnimations)
            {
                if(legacy==null)continue;
                int clipCount=0;
                foreach(AnimationState state in legacy)clipCount++;
                if(clipCount>0)meshyLegacyPresent=true;
                legacy.playAutomatically=false;
                legacy.Stop();
            }
            if(meshyLegacyPresent) meshyAnimator.enabled=false;
            Debug.Log("Pet Town GLB: legacy Animation components="+meshyLegacyAnimations.Length+
                      ", imported clips="+(meshyLegacyPresent?"yes":"no")+
                      ", Animator controller="+(meshyAnimator.runtimeAnimatorController!=null));
            // Never autoplay a running-only GLB while the player is stationary.
            meshyAnimator.speed=0f;
            usingMeshyPlayer=true;
            Debug.Log("Pet Town 3D: Meshy player model loaded.");
            return;
        }
        Debug.LogWarning("Pet Town 3D: MeshyPlayer prefab not found. Showing placeholder character. Use menu Pet Town 3D > Install Meshy Player.");
        BuildPerson(hero.transform,true,0);
    }
    void SpawnVillager(Vector3 p)
    {
        if(IsWater(p.x,p.z))p=shopPosition+new Vector3(10,0,10);
        var root=new GameObject("NPC_SINGLE_ROOT_REPLACEABLE");
        root.transform.position=new Vector3(p.x,Ground(p.x,p.z),p.z);
        BuildPerson(root.transform,false,villagers.Count);
        villagers.Add(root);
    }
    void Message(string message) {notice=message;noticeTime=Time.time+6f;}
    void ClearGhost() {if(ghost!=null)Destroy(ghost);ghost=null;}
    void SetMode(Mode m,int index=0)
    {
        mode=m;selected=index;ClearGhost();
        if(m==Mode.Build || m==Mode.Furniture)
        {
            ghost=Part(PrimitiveType.Cube,"PLACEMENT_PREVIEW",Vector3.zero,new Vector3(m==Mode.Furniture?2:8,.1f,m==Mode.Furniture?2:8),Mat(new Color(.3f,.9f,.6f,.7f)));
            Destroy(ghost.GetComponent<Collider>());
        }
    }
    void OnGUI()
    {
        if(titleStyle==null)
        {
            titleStyle=new GUIStyle(GUI.skin.label){fontSize=22,fontStyle=FontStyle.Bold};
            titleStyle.normal.textColor=Color.white;
            textStyle=new GUIStyle(GUI.skin.label){fontSize=15};textStyle.normal.textColor=Color.white;
        }
        GUI.Box(new Rect(8,8,280,mode==Mode.Start?230:460),"PET TOWN 3D  |  PROTOTYPE");
        GUILayout.BeginArea(new Rect(20,35,260,mode==Mode.Start?195:425));
        GUILayout.Label("Coins: "+money+"    Residents: "+population,textStyle);
        GUILayout.Label("Day "+day+"  |  Shop Lv "+shopLevel+"  |  Fame "+reputation,textStyle);
        GUILayout.Label("Dogs "+dogStock+" / Cats "+catStock+" / Bunnies "+rabbitStock,textStyle);
        GUILayout.Label("Adoptions: "+sold+"  |  Missed: "+missedOrders,textStyle);
        if(orderPet>=0) GUILayout.Label("CUSTOMER WANTS: "+petNames[orderPet]+" ("+Mathf.CeilToInt(orderDeadline-Time.time)+"s)",textStyle);
        if(mode==Mode.Start)
        {
            GUILayout.Space(12);GUILayout.Label("Click anywhere on dry land",textStyle);
            GUILayout.Label("to choose your Pet Shop location.",textStyle);
            GUILayout.Label("River and hills are part of the map.",textStyle);
        }
        else
        {
            if(GUILayout.Button("Explore / Move (WASD)")) SetMode(Mode.Play);
            if(GUILayout.Button("Build town / choose building"))SetMode(Mode.Build);
            if(GUILayout.Button("Decorate Pet Shop"))SetMode(Mode.Furniture);
            if(GUILayout.Button("Customize my character"))SetMode(Mode.Customize);
            if(GUILayout.Button("Order 2 puppies (-120)")) BuyPets(0,120);
            if(GUILayout.Button("Order 2 kittens (-120)")) BuyPets(1,120);
            if(shopLevel>=2 && GUILayout.Button("Order 2 bunnies (-180)")) BuyPets(2,180);
            if(orderPet>=0 && GUILayout.Button("SERVE CUSTOMER [E]")) ServeOrder();
            if(reputation>=shopLevel*10 && GUILayout.Button("Upgrade Shop Level (-"+(shopLevel*400)+")"))
            {if(money>=shopLevel*400){money-=shopLevel*400;shopLevel++;Message("Shop upgraded! Bunny stock unlocks at level 2.");SaveGame();}}
            if(GUILayout.Button("Toggle roof view")){showRoofs=!showRoofs;foreach(var b in buildings) if(b!=null)foreach(var r in b.GetComponentsInChildren<Transform>(true))if(r.name=="Toggle_Roof")r.gameObject.SetActive(showRoofs);}
            if(GUILayout.Button("Save game (F5)"))SaveGame();
            if(GUILayout.Button("Reset save")){PlayerPrefs.DeleteKey("PetTown3D_Save");Message("Save removed. Restart Play mode.");}
        }
        GUILayout.EndArea();
        if(mode==Mode.Build)
        {
            GUI.Box(new Rect(Screen.width-235,8,225,350),"BUILDINGS");
            GUILayout.BeginArea(new Rect(Screen.width-225,38,205,310));
            for(int i=0;i<types.Length;i++){int k=i;if(GUILayout.Button(types[i]+"  "+costs[i]))selected=k;}
            GUILayout.Label("Selected: "+types[selected],textStyle);GUILayout.EndArea();
        }
        if(mode==Mode.Furniture)
        {
            GUI.Box(new Rect(Screen.width-230,8,220,275),"FURNITURE (50 coins)");
            GUILayout.BeginArea(new Rect(Screen.width-220,38,200,230));
            for(int i=0;i<furniture.Length;i++){int k=i;if(GUILayout.Button(furniture[i]))furnitureChoice=k;}
            GUILayout.Label("Selected: "+furniture[furnitureChoice],textStyle);GUILayout.EndArea();
        }
        if(mode==Mode.Customize)
        {
            GUI.Box(new Rect(Screen.width-245,8,235,275),"PLAYER CUSTOMIZATION");
            GUILayout.BeginArea(new Rect(Screen.width-235,38,215,230));
            if(GUILayout.Button("Hair style: "+hairStyle))hairStyle=(hairStyle+1)%4;
            if(GUILayout.Button("Face style: "+faceStyle))faceStyle=(faceStyle+1)%4;
            if(GUILayout.Button("Body style: "+bodyStyle))bodyStyle=(bodyStyle+1)%4;
            if(GUILayout.Button("Leg style: "+legStyle))legStyle=(legStyle+1)%4;
            if(GUILayout.Button("Accessory: "+accessory))accessory=(accessory+1)%3;
            if(GUILayout.Button("Apply character")){RebuildHero();SaveGame();SetMode(Mode.Play);}
            GUILayout.EndArea();
        }
        GUI.Box(new Rect(Screen.width/2-265,Screen.height-70,530,62),"");
        GUI.Label(new Rect(Screen.width/2-250,Screen.height-64,510,25),"WASD move | Right drag rotate | Q/E 45 deg | R reset | Wheel zoom | F5 save",textStyle);
        if(Time.time<noticeTime)GUI.Label(new Rect(Screen.width/2-250,Screen.height-38,510,22),notice,textStyle);
        GUI.Label(new Rect(Screen.width-330,Screen.height-35,320,25),"Far southeast: DARK PET SHOP (preview)",textStyle);
    }

    void BuyPets(int pet,int price)
    {
        if(money<price){Message("Not enough coins to order pets");return;}
        money-=price;
        if(pet==0)dogStock+=2;else if(pet==1)catStock+=2;else rabbitStock+=2;
        inventory=dogStock+catStock+rabbitStock;
        Message("Two "+petNames[pet]+" pets arrived!");SaveGame();
    }
    void StartOrder()
    {
        if(shop==null)return;
        orderTimer=0;orderPet=UnityEngine.Random.Range(0,shopLevel>=2?3:2);
        orderDeadline=Time.time+42f;
        Vector3 p=shopPosition+new Vector3(0,0,-7);
        waitingCustomer=new GameObject("WAITING_CUSTOMER_REPLACEABLE");
        waitingCustomer.transform.position=new Vector3(p.x,Ground(p.x,p.z),p.z);
        Part(PrimitiveType.Capsule,"Body",waitingCustomer.transform.position+Vector3.up*1.2f,new Vector3(.75f,1.3f,.7f),Mat(new Color(.84f,.5f,.78f)),waitingCustomer.transform);
        Part(PrimitiveType.Sphere,"Head",waitingCustomer.transform.position+Vector3.up*2.5f,Vector3.one,skin,waitingCustomer.transform);
        Message("Customer arrived! Wants a "+petNames[orderPet]+". Press E or SERVE.");
    }
    void ServeOrder()
    {
        if(orderPet<0)return;
        int count=orderPet==0?dogStock:orderPet==1?catStock:rabbitStock;
        if(count<=0){Message("Out of "+petNames[orderPet]+" stock. Order more!");return;}
        if(orderPet==0)dogStock--;else if(orderPet==1)catStock--;else rabbitStock--;
        inventory=dogStock+catStock+rabbitStock;
        int income=(orderPet==2?330:240)+Mathf.Min(150,shopLevel*20)+Mathf.Min(100,population*2);
        money+=income;sold++;completedOrders++;reputation+=2;
        Message("Adoption successful! +"+income+" coins, +2 fame");
        EndOrder();SaveGame();
    }
    void FailOrder()
    {
        missedOrders++;reputation=Mathf.Max(0,reputation-1);
        Message("Customer left without a pet. -1 fame");EndOrder();SaveGame();
    }
    void EndOrder()
    {
        orderPet=-1;orderTimer=0;
        if(waitingCustomer!=null)Destroy(waitingCustomer);
        waitingCustomer=null;
    }
    void CreatePetDisplays()
    {
        if(shop==null)return;
        for(int i=0;i<4;i++)
        {
            Vector3 p=shopPosition+new Vector3(-4+i*2.6f,0,3);
            GameObject pet=new GameObject("PET_PLACEHOLDER_"+i+"_REPLACEABLE");pet.transform.position=p;
            Part(PrimitiveType.Sphere,"Body",p+Vector3.up*.65f,new Vector3(.9f,.65f,1.2f),i%2==0?roofMat:wood,pet.transform);
            Part(PrimitiveType.Sphere,"Head",p+new Vector3(0,1,-.5f),new Vector3(.8f,.7f,.7f),i%2==0?roofMat:wood,pet.transform);
            Part(PrimitiveType.Cube,"Pet_Bed",p+Vector3.up*.15f,new Vector3(1.8f,.3f,1.8f),wall,pet.transform);
        }
    }

    [Serializable] class SaveData
    {
        public int coins,population,sold,inventory,hair,face,body,legs,acc,rep,level,day,dogs,cats,bunnies,done,missed;
        public float shopX=999,shopZ;
        public List<int> types=new List<int>();
        public List<float> x=new List<float>(),z=new List<float>();
    }
    void SaveGame()
    {
        SaveData s=new SaveData{coins=money,population=population,sold=sold,inventory=inventory,
            hair=hairStyle,face=faceStyle,body=bodyStyle,legs=legStyle,acc=accessory,
            rep=reputation,level=shopLevel,day=day,dogs=dogStock,cats=catStock,bunnies=rabbitStock,done=completedOrders,missed=missedOrders,
            shopX=shop==null?999:shopPosition.x,shopZ=shopPosition.z};
        foreach(var b in buildings)
        {
            if(b==null||b==shop)continue;
            string n=b.name;for(int i=0;i<types.Length;i++)if(n.StartsWith(types[i].Replace(" ","_")))
            {s.types.Add(i);s.x.Add(b.transform.position.x);s.z.Add(b.transform.position.z);break;}
        }
        PlayerPrefs.SetString("PetTown3D_Save",JsonUtility.ToJson(s));PlayerPrefs.Save();Message("Game saved");
    }
    void LoadGame()
    {
        string json=PlayerPrefs.GetString("PetTown3D_Save","");
        if(string.IsNullOrEmpty(json))return;
        try
        {
            var s=JsonUtility.FromJson<SaveData>(json);
            money=s.coins;population=s.population;sold=s.sold;inventory=s.inventory;
            hairStyle=s.hair;faceStyle=s.face;bodyStyle=s.body;legStyle=s.legs;accessory=s.acc;
            reputation=s.rep;shopLevel=Mathf.Max(1,s.level);day=Mathf.Max(1,s.day);dogStock=s.dogs;catStock=s.cats;rabbitStock=s.bunnies;completedOrders=s.done;missedOrders=s.missed;
            if(s.shopX!=999)
            {
                Vector3 p=new Vector3(s.shopX,Ground(s.shopX,s.shopZ),s.shopZ);
                CreateBuilding(0,p,false);CreateHero(p+new Vector3(8,0,8));CreatePetDisplays();
            }
            for(int i=0;i<s.types.Count;i++)
            {
                Vector3 p=new Vector3(s.x[i],Ground(s.x[i],s.z[i]),s.z[i]);
                CreateBuilding(s.types[i],p,false);
            }
            Message("Saved town loaded");
        }catch(Exception e){Debug.LogWarning("Save could not be loaded: "+e.Message);}
    }
}
